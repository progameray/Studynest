# StudyNest + PlayPocket

A responsive, no-build static website with an educational math homepage and a separate arcade portal. It uses vanilla HTML, CSS, and JavaScript to keep the project lightweight and easy to deploy without package installation.

## Run locally

1. Unzip the project.
2. Open `index.html` in a modern browser, or serve the folder with any static web server (recommended for realistic browser behavior):
   - Python: `python -m http.server 8000`
   - Visit `http://localhost:8000`
3. Click **Privacy** in the footer or **Visit the arcade** to open PlayPocket in a new `about:blank` tab. If the browser blocks pop-ups, the site falls back to showing the portal in the current tab.

## What's included

- Eight math study topics: arithmetic, fractions, decimals, percentages, pre-algebra, algebra, geometry, and basic statistics.
- Searchable lessons with formulas, worked examples, step-by-step guidance, and topic-specific quizzes with explanations.
- Quiz progress saved in `localStorage` on the current device/browser.
- Dark PlayPocket portal with search, categories, favorites, recently played, movie discovery links, search provider choices, and useful web tools.
- Twelve built-in mini-games: 2048, Tic-Tac-Toe, Memory Match, Number Guess, Reaction Lab, Math Sprint, Rock Paper Scissors, Tap Dash, Color Memory, Pattern Finder, Sports Quiz, and Word Scramble, plus third-party game directory links.
- Favorites and recent-game history stored locally in the browser.
- Keyboard accessibility, responsive layouts, visible focus styles, and reduced-motion support.

## Add games

In `index.html`, find the `games` array inside the `portalBoot` function. Each game entry includes:

- `id`: unique stable identifier
- `title`: display title
- `cat`: one of the category labels
- `emoji`, `c1`, `c2`: card artwork styling
- `desc`: short description
- `kind`: `link` for a third-party link, or a built-in game type handled by `renderGame()`
- `url`: required for `kind: 'link'`

For a new built-in game, add a new `kind` and implement it in `renderGame(g)`. External entries are intentionally opened on their provider's site instead of being embedded without permission. Verify licensing, age suitability, accessibility, and provider terms before listing or embedding any game. The starter catalog includes 32 entries and demonstrates the data structure and filtering system; add more entries to scale toward hundreds. It is not a guarantee that every external site is available on every network.

## Browser and deployment notes

- Opening `about:blank` and writing the portal document works in browsers that permit the user-initiated pop-up. Some browsers, extensions, content policies, or managed devices may block it. The current-tab fallback handles that case.
- A blank tab is not a proxy and does not bypass browser, network, school, or administrator restrictions.
- External sites can refuse embedding, change their URLs, require sign-in, or be unavailable. This project opens those entries as external links and does not host copyrighted movies or games.
- No backend or external API configuration is required. `localStorage` is local to the browser profile; clearing browser site data removes saved progress, favorites, and recent games.
- Before production deployment, test target browsers and school-managed devices, review all third-party destinations, and consider a Content Security Policy appropriate to the final hosting setup.


## Version 2 notes

- Keeps the math-learning homepage and separate-tab behavior.
- The separate portal is identified as an entertainment portal rather than presented as a privacy feature.
- `about:blank` behavior depends on browser popup settings; it does not bypass school/network restrictions.
- Third-party game links and embeds depend on the providers' availability and embedding permissions.
